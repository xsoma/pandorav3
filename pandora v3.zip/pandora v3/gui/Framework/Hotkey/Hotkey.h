#pragma once

namespace GUI::Controls {
	void Hotkey( const std::string& name, const std::string& var_name, bool type_selection = true );
}
