#pragma once

namespace Menu {
	void Draw( );
}